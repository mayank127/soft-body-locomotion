This library (GLUI User Interface Library, version 2.35) is not a part of Vega.
GLUI is a GLUT-based C++ user interface library.
It was downloaded from http://glui.sourceforge.net/ .
It is licensed under LGPL.

GLUI is necessary to compile and link the provided "interactiveDeformableSimulator" driver executable, but is otherwise not referenced by Vega. The driver executable uses GLUI for the user interface (buttons, edit boxes, etc.).

